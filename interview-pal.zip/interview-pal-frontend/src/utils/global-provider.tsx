import {
  createContext,
  useState,
  useEffect,
  useCallback,
  Dispatch,
  SetStateAction,
} from "react";
import { AuthSession } from "@supabase/supabase-js";
import { Outlet } from "@tanstack/react-router";
import { supabase } from "./supabase-client";
import { toast } from "@/hooks/use-toast";
import { ToastAction } from "@/components/ui/toast";

type GlobalContextProps = {
  session: AuthSession | null;
  profile: Profile | null;
  isResetPasswordValid: boolean;
  setProfile: Dispatch<SetStateAction<Profile | null>>;
  setIsResetPasswordValid: Dispatch<SetStateAction<boolean>>;
};

type Profile = {
  id: string;
  createdAt: string;
  firstName: string;
  lastName: string;
  email: string;
};

export const GlobalContext = createContext<GlobalContextProps>(undefined!);

export const GlobalProvider = ({
  children = <Outlet />,
}: {
  children?: React.ReactNode;
}) => {
  const [session, setSession] = useState<AuthSession | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [isResetPasswordValid, setIsResetPasswordValid] = useState(false);

  useEffect(() => {
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (event === "PASSWORD_RECOVERY") {
        setIsResetPasswordValid(true);
      }
      setSession(session);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const fetchProfile = useCallback(async () => {
    const { data, error } = await supabase.from("users").select();
    if (!error) {
      setProfile(data[0]);
    } else {
      toast({
        title: "Profile Error",
        description: "Profile was not fetched. Something went wrong.",
        action: <ToastAction altText="OKAY">OK</ToastAction>,
      });
    }
  }, []);

  useEffect(() => {
    if (!profile && session?.user.id) {
      fetchProfile();
    }
  }, [profile, session?.user.id, fetchProfile]);

  return (
    <GlobalContext.Provider
      value={{
        session,
        profile,
        isResetPasswordValid,
        setProfile,
        setIsResetPasswordValid,
      }}
    >
      {children}
    </GlobalContext.Provider>
  );
};
