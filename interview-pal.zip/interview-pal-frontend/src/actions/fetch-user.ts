import { supabase } from "@/utils/supabase-client";

export async function fetchUser() {
  const { data, error } = await supabase.auth.getUser();
  return { data, error };
}
