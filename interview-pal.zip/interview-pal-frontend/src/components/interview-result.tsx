import { useState } from "react";
import {
  Loader2,
  Share,
  Download,
  ChevronDown,
  ChevronUp,
  Copy,
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface QuestionFeedback {
  question_id: number;
  score: number;
  feedback: string;
  improvement_suggestions: string;
}

interface OverallFeedback {
  overall_score: number;
  strengths: string;
  improvement_areas: string;
  preparation_advice: string;
}

interface Feedback {
  question_feedback: QuestionFeedback[];
  overall_feedback: OverallFeedback;
}

interface InterviewQuestion {
  id: number;
  question: string;
  type: "technical" | "behavioral" | "project";
}

interface InterviewResultsProps {
  resultId: string;
  questions: InterviewQuestion[];
  answers: Record<number, string>;
  feedback: Feedback;
  onStartNewInterview: () => void;
}

export default function InterviewResults({
  resultId,
  questions,
  answers,
  feedback,
  onStartNewInterview,
}: InterviewResultsProps) {
  const [activeTab, setActiveTab] = useState<string>("summary");
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>(
    {}
  );
  const [copySuccess, setCopySuccess] = useState<string | null>(null);

  // Function to get a descriptive rating based on score - stricter scale
  const getRatingText = (score: number) => {
    if (score >= 9) return "Outstanding"; // Truly exceptional, rare
    if (score >= 7) return "Strong"; // Above average, solid performance
    if (score >= 5) return "Acceptable"; // Meets minimum expectations
    if (score >= 3) return "Needs Work"; // Below expectations
    return "Inadequate"; // Significant improvement needed
  };

  // Function to get color class based on score - stricter scale
  const getScoreColorClass = (score: number) => {
    if (score >= 9) return "text-green-600";
    if (score >= 7) return "text-emerald-600";
    if (score >= 5) return "text-amber-600";
    if (score >= 3) return "text-orange-600";
    return "text-red-600";
  };

  // Ensure feedback has all required fields with default values
  const normalizedFeedback = {
    question_feedback: feedback.question_feedback || [],
    overall_feedback: {
      overall_score: feedback.overall_feedback?.overall_score || 0,
      strengths:
        feedback.overall_feedback?.strengths || "No strengths provided",
      improvement_areas:
        feedback.overall_feedback?.improvement_areas ||
        "No improvement areas provided",
      preparation_advice:
        feedback.overall_feedback?.preparation_advice ||
        "No preparation advice provided",
    },
  };

  // Function to get badge color based on question type
  const getQuestionTypeColor = (type: string) => {
    switch (type) {
      case "technical":
        return "bg-blue-100 text-blue-800";
      case "behavioral":
        return "bg-purple-100 text-purple-800";
      case "project":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  // Toggle expanded state for a question
  const toggleExpanded = (id: string) => {
    setExpandedItems((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  // Copy feedback to clipboard
  const copyFeedback = () => {
    // Create a formatted text version of the feedback
    let feedbackText = `INTERVIEW FEEDBACK\n\n`;
    feedbackText += `Overall Score: ${
      normalizedFeedback.overall_feedback.overall_score
    }/10 - ${getRatingText(
      normalizedFeedback.overall_feedback.overall_score
    )}\n\n`;
    feedbackText += `STRENGTHS:\n${normalizedFeedback.overall_feedback.strengths}\n\n`;
    feedbackText += `AREAS FOR IMPROVEMENT:\n${normalizedFeedback.overall_feedback.improvement_areas}\n\n`;
    feedbackText += `PREPARATION ADVICE:\n${normalizedFeedback.overall_feedback.preparation_advice}\n\n`;
    feedbackText += `QUESTION-BY-QUESTION FEEDBACK:\n\n`;

    normalizedFeedback.question_feedback.forEach((qf) => {
      const q = questions.find((que) => que.id === qf.question_id);
      if (q) {
        feedbackText += `Question (${q.type}): ${q.question}\n`;
        feedbackText += `Your Answer: ${
          answers[qf.question_id] || "No answer provided"
        }\n`;
        feedbackText += `Score: ${qf.score}/10\n`;
        feedbackText += `Feedback: ${qf.feedback}\n`;
        feedbackText += `Improvement Suggestions: ${qf.improvement_suggestions}\n\n`;
      }
    });

    navigator.clipboard
      .writeText(feedbackText)
      .then(() => {
        setCopySuccess("Copied to clipboard!");
        setTimeout(() => setCopySuccess(null), 2000);
      })
      .catch(() => {
        setCopySuccess("Failed to copy");
        setTimeout(() => setCopySuccess(null), 2000);
      });
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="w-full max-w-4xl mx-auto">
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-2xl">Interview Feedback</CardTitle>
              <CardDescription>
                Based on your answers, here's an evaluation of your interview
                performance
              </CardDescription>
            </div>
            <div className="hidden sm:flex gap-2">
              <Button variant="outline" size="sm" onClick={copyFeedback}>
                <Copy className="h-4 w-4 mr-2" />
                {copySuccess || "Copy"}
              </Button>
              <Button variant="outline" size="sm" onClick={onStartNewInterview}>
                Start New Interview
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          <Tabs
            defaultValue="summary"
            value={activeTab}
            onValueChange={setActiveTab}
          >
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="summary">Summary</TabsTrigger>
              <TabsTrigger value="detailed">Detailed Feedback</TabsTrigger>
            </TabsList>

            <TabsContent value="summary" className="space-y-6 pt-4">
              {/* Overall Score Section */}
              <div className="bg-muted p-6 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-xl font-semibold">Overall Score</h3>
                  <span
                    className={`text-2xl font-bold ${getScoreColorClass(
                      feedback.overall_feedback.overall_score
                    )}`}
                  >
                    {feedback.overall_feedback.overall_score}/10
                  </span>
                </div>
                <Progress
                  value={feedback.overall_feedback.overall_score * 10}
                  className="h-2 mb-4"
                />
                <p className="text-lg font-medium mb-2">
                  Rating:{" "}
                  <span
                    className={getScoreColorClass(
                      feedback.overall_feedback.overall_score
                    )}
                  >
                    {getRatingText(feedback.overall_feedback.overall_score)}
                  </span>
                </p>
              </div>

              {/* Strengths & Areas for Improvement */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold">Strengths</h3>
                  <p className="text-sm">
                    {normalizedFeedback.overall_feedback.strengths}
                  </p>
                </div>
                <div className="space-y-3">
                  <h3 className="text-lg font-semibold">
                    Areas for Improvement
                  </h3>
                  <p className="text-sm">
                    {normalizedFeedback.overall_feedback.improvement_areas}
                  </p>
                </div>
              </div>

              {/* Preparation Advice */}
              <div className="mt-6 p-4 border rounded-md bg-blue-50">
                <h3 className="text-lg font-semibold mb-2">
                  Preparation Advice
                </h3>
                <p className="text-sm">
                  {normalizedFeedback.overall_feedback.preparation_advice}
                </p>
              </div>

              {/* Question Score Summary */}
              <div className="mt-6">
                <h3 className="text-lg font-semibold mb-4">Question Scores</h3>
                <div className="space-y-2">
                  {normalizedFeedback.question_feedback.map((qFeedback) => {
                    const question = questions.find(
                      (q) => q.id === qFeedback.question_id
                    );
                    if (!question) return null;

                    return (
                      <div
                        key={qFeedback.question_id}
                        className="flex items-center justify-between p-3 bg-muted rounded-md"
                      >
                        <div className="flex items-center space-x-2">
                          <Badge
                            variant="outline"
                            className={getQuestionTypeColor(question.type)}
                          >
                            {question.type.charAt(0).toUpperCase() +
                              question.type.slice(1)}
                          </Badge>
                          <span className="text-sm font-medium truncate max-w-[300px]">
                            {question.question.length > 60
                              ? `${question.question.substring(0, 60)}...`
                              : question.question}
                          </span>
                        </div>
                        <span
                          className={`text-sm font-bold ${getScoreColorClass(
                            qFeedback.score
                          )}`}
                        >
                          {qFeedback.score}/10
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="detailed" className="space-y-6 pt-4">
              {/* Question-by-Question Feedback */}
              <div>
                <h3 className="text-xl font-semibold mb-4">
                  Question-by-Question Feedback
                </h3>

                <div className="space-y-4">
                  {normalizedFeedback.question_feedback.map((qFeedback) => {
                    const question = questions.find(
                      (q) => q.id === qFeedback.question_id
                    );
                    if (!question) return null;

                    const isExpanded =
                      expandedItems[`q-${qFeedback.question_id}`];

                    return (
                      <div
                        key={qFeedback.question_id}
                        className="border rounded-lg overflow-hidden"
                      >
                        {/* Question Header */}
                        <div
                          className="p-4 bg-muted flex items-center justify-between cursor-pointer"
                          onClick={() =>
                            toggleExpanded(`q-${qFeedback.question_id}`)
                          }
                        >
                          <div className="flex items-center space-x-2">
                            <Badge
                              variant="outline"
                              className={getQuestionTypeColor(question.type)}
                            >
                              {question.type.charAt(0).toUpperCase() +
                                question.type.slice(1)}
                            </Badge>
                            <span className="font-medium">
                              {question.question.length > 70
                                ? `${question.question.substring(0, 70)}...`
                                : question.question}
                            </span>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span
                              className={`font-bold ${getScoreColorClass(
                                qFeedback.score
                              )}`}
                            >
                              {qFeedback.score}/10
                            </span>
                            {isExpanded ? (
                              <ChevronUp size={18} />
                            ) : (
                              <ChevronDown size={18} />
                            )}
                          </div>
                        </div>

                        {/* Expanded Content */}
                        {isExpanded && (
                          <div className="p-4 space-y-4">
                            <div>
                              <h4 className="font-semibold mb-1">Question:</h4>
                              <p className="mb-3">{question.question}</p>
                              <h4 className="font-semibold mb-1">
                                Your Answer:
                              </h4>
                              <p className="p-3 bg-muted/50 rounded-md whitespace-pre-wrap">
                                {answers[qFeedback.question_id] ||
                                  "No answer provided"}
                              </p>
                            </div>

                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                              <div>
                                <h4 className="font-semibold mb-1">
                                  Feedback:
                                </h4>
                                <p>{qFeedback.feedback}</p>
                              </div>
                              <div>
                                <h4 className="font-semibold mb-1">
                                  Improvement Suggestions:
                                </h4>
                                <p>{qFeedback.improvement_suggestions}</p>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>

        <CardFooter className="flex justify-between">
          <Button variant="outline" onClick={onStartNewInterview}>
            Start New Interview
          </Button>
          <Button onClick={copyFeedback}>
            <Copy className="h-4 w-4 mr-2" />
            {copySuccess || "Copy Feedback"}
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
