import { GlobalContext } from "@/utils/global-provider";
import { useContext } from "react";

export const useGlobalProvider = () => {
  return useContext(GlobalContext);
};
