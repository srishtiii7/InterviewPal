import { createFileRoute, redirect } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Upload, File, Trash2, Eye, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { useUser } from "@/hooks/use-user";

type ResumeFile = {
  name: string;
  url: string;
  file_url: string;
};

export const Route = createFileRoute("/_site/home")({
  component: RouteComponent,
});

function RouteComponent() {
  const { user } = useUser();

  const [resume, setResume] = useState<ResumeFile | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    if (!user) {
      redirect({ to: "/login" });
    } else {
      fetchExistingResume();
    }
  }, [user]);

  const fetchExistingResume = async () => {
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/resume/${user?.id}`,
        {
          headers: {
            "X-User-Id": user?.id!,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        if (data.data) {
          setResume({
            name: data.data.filename,
            url: data.data.file_url, // Use the Supabase Storage URL
            file_url: data.data.file_url,
          });
        }
      }
    } catch (error) {
      setError("Failed to fetch resume");
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = event.target.files?.[0];
    if (file) {
      if (
        file.type === "application/pdf" ||
        file.type ===
          "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
      ) {
        if (file.size <= 5 * 1024 * 1024) {
          setIsUploading(true);
          setError(null);

          const formData = new FormData();
          formData.append("file", file);

          try {
            const response = await fetch(
              `${import.meta.env.VITE_API_URL}/api/resume`,
              {
                method: "POST",
                headers: {
                  "X-User-Id": user?.id!,
                },
                body: formData,
              }
            );

            if (!response.ok) {
              throw new Error("Upload failed");
            }

            const data = await response.json();
            setResume({
              name: file.name,
              url: data.data.file_url,
              file_url: data.data.file_url,
            });
          } catch (error) {
            setError("Failed to upload resume");
          } finally {
            setIsUploading(false);
          }
        } else {
          setError("File too large! Max size: 5MB.");
        }
      } else {
        setError("Oops! Only PDF and DOCX files are allowed.");
      }
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL}/api/resume/${user?.id}`,
        {
          method: "DELETE",
          headers: {
            "X-User-Id": user?.id!,
          },
        }
      );

      if (!response.ok) {
        throw new Error("Delete failed");
      }

      setResume(null);
    } catch (error) {
      setError("Failed to delete resume");
    } finally {
      setIsDeleting(false);
      setIsDeleteDialogOpen(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-65px)]">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-2xl w-full mx-auto px-4 min-h-[calc(100vh-65px)] flex flex-col justify-center">
      <h1 className="text-3xl font-bold text-center mb-2">
        {resume ? "Your Resume is Ready!" : "Upload Your Resume"}
      </h1>
      <p className="text-center mb-8">
        {resume
          ? "You can update or delete your resume anytime."
          : "Get ready for your dream job! Upload your resume in PDF or DOCX format."}
      </p>

      {!resume ? (
        <div className="border-2 border-dashed border-muted-foreground rounded-lg p-8 text-center">
          <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
          <label htmlFor="file-upload" className="cursor-pointer">
            <span className="mt-2 block text-muted-foreground text-sm font-semibold">
              {isUploading
                ? "Uploading your resume..."
                : "Drag & Drop your resume here or Click to upload"}
            </span>
            <input
              id="file-upload"
              name="file-upload"
              type="file"
              className="sr-only"
              onChange={handleFileUpload}
              accept=".pdf,.docx"
              disabled={isUploading}
            />
          </label>
          <p className="mt-2 text-xs text-muted-foreground">
            Supports: PDF, DOCX
          </p>
          {isUploading && (
            <div className="mt-4">
              <div className="w-full bg-muted-foreground/50 rounded-full h-2.5">
                <div
                  className="dark:bg-white bg-black h-2.5 rounded-full transition-all duration-300"
                  style={{ width: "50%" }}
                />
              </div>
            </div>
          )}
          {error && (
            <p className="mt-2 text-sm text-red-500 animate-in fade-in slide-in-from-top-1">
              {error}
            </p>
          )}
        </div>
      ) : (
        <>
          <div className="border shadow rounded-lg p-6 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <File className="h-8 w-8" />
                <span className="text-lg font-medium">{resume.name}</span>
              </div>
              <div className="space-x-2">
                <Button
                  onClick={() => window.open(resume.file_url, "_blank")}
                  variant="outline"
                  className="border"
                  disabled={isDeleting}
                >
                  <Eye className="h-4 w-4 mr-1" />
                  View
                </Button>
                <Button
                  onClick={() => setIsDeleteDialogOpen(true)}
                  variant="destructive"
                  className="bg-red-500 hover:bg-red-500/80 text-white"
                  disabled={isDeleting}
                >
                  {isDeleting ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Trash2 className="h-4 w-4 mr-1" />
                  )}
                  Delete
                </Button>
              </div>
            </div>
          </div>
        </>
      )}

      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Resume</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete your resume? This action cannot be
              undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              onClick={() => setIsDeleteDialogOpen(false)}
              variant="outline"
              className="bg-background hover:bg-muted-foreground/10"
              disabled={isDeleting}
            >
              Cancel
            </Button>
            <Button
              onClick={handleDelete}
              variant="destructive"
              className="bg-red-500 hover:bg-red-500/80 text-white"
              disabled={isDeleting}
            >
              {isDeleting ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Trash2 className="h-4 w-4 mr-1" />
              )}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
