import { ThemeProvider } from "@/components/theme-provider";
import { Toaster } from "@/components/ui/toaster";
import { queryClient } from "@/lib/query-client";
import { createFileRoute, Outlet, redirect } from "@tanstack/react-router";
import { QueryClientProvider } from "@tanstack/react-query";
import { UserProvider } from "@/hooks/use-user";
import { fetchUser } from "@/actions/fetch-user";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { Separator } from "@/components/ui/separator";
import { AppSidebar } from "@/components/sidebar";
import { ModeToggle } from "@/components/mode-toggle";

export const Route = createFileRoute("/_site")({
  beforeLoad: async () => {
    const cachedUser = queryClient.getQueryData(["user"]);
    if (cachedUser) return;

    const { data, error } = await fetchUser();
    if (!data?.user || error) {
      throw redirect({ to: "/login" });
    }
  },
  component: SiteLayout,
});

function SiteLayout() {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={"max-h-screen bg-background font-sans antialiased"}>
        <SidebarProvider
          style={
            {
              "--sidebar-width": "350px",
            } as React.CSSProperties
          }
        >
          <AppSidebar />
          <QueryClientProvider client={queryClient}>
            <UserProvider>
              <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
                <SidebarInset>
                  <header className="sticky top-0 flex shrink-0 items-center gap-2 border-b bg-background p-4">
                    <SidebarTrigger className="-ml-1 sm:hidden block" />
                    <Separator
                      orientation="vertical"
                      className="mr-2 h-4 sm:hidden block"
                    />
                    <Breadcrumb>
                      <BreadcrumbList>
                        <BreadcrumbItem className="hidden md:block">
                          <BreadcrumbLink href="#">
                            Interview Pal
                          </BreadcrumbLink>
                        </BreadcrumbItem>
                        <BreadcrumbSeparator className="hidden md:block" />
                        <BreadcrumbItem>
                          <BreadcrumbPage>Upload Resume</BreadcrumbPage>
                        </BreadcrumbItem>
                      </BreadcrumbList>
                    </Breadcrumb>
                  </header>
                  <Outlet />
                  <div className="fixed bottom-4 right-4 z-50">
                    <ModeToggle />
                  </div>
                </SidebarInset>
                <Toaster />
              </ThemeProvider>
            </UserProvider>
          </QueryClientProvider>
        </SidebarProvider>
      </body>
    </html>
  );
}
