import axios from "axios";

interface InterviewQuestion {
  id: number;
  question: string;
  type: "technical" | "behavioral" | "project";
}

interface QuestionFeedback {
  question_id: number;
  score: number;
  feedback: string;
  improvement_suggestions: string;
}

interface OverallFeedback {
  overall_score: number;
  strengths: string;
  improvement_areas: string;
  preparation_advice: string;
}

interface Feedback {
  question_feedback: QuestionFeedback[];
  overall_feedback: OverallFeedback;
}

interface QuestionsResponse {
  questions: InterviewQuestion[];
}

interface SaveResultsResponse {
  result_id: string;
  feedback: Feedback;
}

const API_BASE_URL = `${import.meta.env.VITE_API_URL}/api`;

// Create axios instance with base URL
const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

export const InterviewService = {
  generateQuestions: async (
    userId: string,
    jobDescription: string
  ): Promise<InterviewQuestion[]> => {
    try {
      const response = await apiClient.post<QuestionsResponse>(
        "/interview/generate-questions",
        {
          user_id: userId,
          job_description: jobDescription,
        }
      );

      return response.data.questions;
    } catch (error) {
      console.error("Error generating interview questions:", error);
      throw error;
    }
  },

  generateFeedback: async (
    userId: string,
    questions: InterviewQuestion[],
    answers: Record<number, string>,
    jobDescription: string = ""
  ): Promise<{ resultId: string; feedback: Feedback }> => {
    try {
      // Call the API to generate feedback
      const response = await apiClient.post<any>("/interview/feedback", {
        user_id: userId,
        questions: questions,
        answers: answers,
        job_description: jobDescription,
      });

      console.log("API Response:", response.data);

      // Check if the response has the required feedback structure
      if (response.data) {
        // The API might return { result_id, feedback } OR it might return the feedback directly
        // Check both possibilities

        if (response.data.feedback) {
          // Standard format: { result_id, feedback }
          return {
            resultId: response.data.result_id || `gen-${Date.now()}`,
            feedback: response.data.feedback,
          };
        } else if (
          response.data.overall_feedback &&
          response.data.question_feedback
        ) {
          // Direct feedback format: the response itself is the feedback object
          return {
            resultId: `gen-${Date.now()}`,
            feedback: response.data,
          };
        } else {
          console.error("Unexpected API response structure:", response.data);
          throw new Error("Unexpected API response structure");
        }
      } else {
        throw new Error("Empty API response");
      }
    } catch (error) {
      console.error("Error generating feedback:", error);
      console.log("Using fallback feedback instead");

      // Return fallback feedback if the API call fails
      return {
        resultId: `gen-${Date.now()}`,
        feedback: {
          question_feedback: questions.map((question) => ({
            question_id: question.id,
            score: 0,
            feedback: "No feedback available",
            improvement_suggestions: "No suggestions available",
          })),
          overall_feedback: {
            overall_score: 0,
            strengths: "No strengths available",
            improvement_areas: "No areas for improvement available",
            preparation_advice: "No preparation advice available",
          },
        },
      };
    }
  },
};

export default InterviewService;
