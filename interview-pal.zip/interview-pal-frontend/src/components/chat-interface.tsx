import { useState, useRef, useEffect } from "react";
import { ArrowUp, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";

type MessageType = "user" | "system";

interface Message {
  id: string;
  content: string;
  type: MessageType;
  completed?: boolean;
}

interface InterviewQuestion {
  id: number;
  question: string;
  type: "technical" | "behavioral" | "project";
}

interface ChatInterfaceProps {
  userId: string;
  questions: InterviewQuestion[];
  onInterviewComplete: (
    answers: Record<number, string>,
    isComplete: boolean
  ) => void;
}

export default function ChatInterface({
  userId,
  questions,
  onInterviewComplete,
}: ChatInterfaceProps) {
  const [inputValue, setInputValue] = useState<string>("");
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0);
  const [messages, setMessages] = useState<Message[]>([]);
  const [isStreaming, setIsStreaming] = useState<boolean>(false);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [hasTyped, setHasTyped] = useState<boolean>(false);
  const [isMobile, setIsMobile] = useState<boolean>(false);

  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputContainerRef = useRef<HTMLDivElement>(null);
  const mainContainerRef = useRef<HTMLDivElement>(null);

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      const isMobileDevice = window.innerWidth < 768;
      setIsMobile(isMobileDevice);
    };

    checkMobile();
    window.addEventListener("resize", checkMobile);

    return () => {
      window.removeEventListener("resize", checkMobile);
    };
  }, []);

  // Focus textarea on component mount (only on desktop)
  useEffect(() => {
    if (textareaRef.current && !isMobile) {
      textareaRef.current.focus();
    }
  }, [isMobile]);

  // Add the first question when the component mounts
  useEffect(() => {
    if (questions.length > 0 && messages.length === 0) {
      addQuestionMessage(questions[0]);
    }
  }, [questions]);

  // Scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const focusTextarea = () => {
    if (textareaRef.current && !isMobile) {
      textareaRef.current.focus();
    }
  };

  const addQuestionMessage = (question: InterviewQuestion) => {
    const questionMessage: Message = {
      id: `question-${question.id}`,
      content: question.question,
      type: "system",
      completed: true,
    };

    setMessages((prev) => [...prev, questionMessage]);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newValue = e.target.value;

    if (!isStreaming) {
      setInputValue(newValue);

      if (newValue.trim() !== "" && !hasTyped) {
        setHasTyped(true);
      } else if (newValue.trim() === "" && hasTyped) {
        setHasTyped(false);
      }

      const textarea = textareaRef.current;
      if (textarea) {
        textarea.style.height = "auto";
        const newHeight = Math.max(24, Math.min(textarea.scrollHeight, 160));
        textarea.style.height = `${newHeight}px`;
      }
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (inputValue.trim() && !isStreaming) {
      // Vibrate on message submit for mobile devices
      if (navigator.vibrate) {
        navigator.vibrate(50);
      }

      const userAnswer = inputValue.trim();

      // Add user message
      const newUserMessage: Message = {
        id: `user-${Date.now()}`,
        content: userAnswer,
        type: "user",
      };

      // Store the answer
      setAnswers((prev) => ({
        ...prev,
        [questions[currentQuestionIndex].id]: userAnswer,
      }));

      // Clear input
      setInputValue("");
      setHasTyped(false);

      if (textareaRef.current) {
        textareaRef.current.style.height = "auto";
      }

      // Add the message
      setMessages((prev) => [...prev, newUserMessage]);

      // Focus textarea on desktop only
      if (!isMobile) {
        focusTextarea();
      } else {
        // Blur textarea on mobile to dismiss keyboard
        if (textareaRef.current) {
          textareaRef.current.blur();
        }
      }

      // Move to next question or finish interview
      const nextQuestionIndex = currentQuestionIndex + 1;

      if (nextQuestionIndex < questions.length) {
        // Show next question after a short delay
        setTimeout(() => {
          setCurrentQuestionIndex(nextQuestionIndex);
          addQuestionMessage(questions[nextQuestionIndex]);
        }, 500);
      } else {
        // Interview complete
        setTimeout(() => {
          const completionMessage: Message = {
            id: `completion-${Date.now()}`,
            content:
              "Thank you for completing the interview! Your responses have been recorded. Generating feedback...",
            type: "system",
            completed: true,
          };

          setMessages((prev) => [...prev, completionMessage]);

          // Call the onInterviewComplete callback with all answers
          onInterviewComplete(answers, true);
        }, 500);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    // Handle Cmd+Enter on both mobile and desktop
    if (!isStreaming && e.key === "Enter" && e.metaKey) {
      e.preventDefault();
      handleSubmit(e);
      return;
    }

    // Handle Enter key (without Shift) on desktop only
    if (!isStreaming && !isMobile && e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit(e);
    }
  };

  const handleInputContainerClick = (e: React.MouseEvent<HTMLDivElement>) => {
    // Focus textarea when clicking the input container (but not buttons)
    if (
      e.target === e.currentTarget ||
      (e.currentTarget === inputContainerRef.current &&
        !(e.target as HTMLElement).closest("button"))
    ) {
      focusTextarea();
    }
  };

  const copyMessageToClipboard = (content: string) => {
    navigator.clipboard
      .writeText(content)
      .then(() => {
        // Could show a toast notification here
      })
      .catch((err) => {
        console.error("Failed to copy message: ", err);
      });
  };

  return (
    <div
      ref={mainContainerRef}
      className="flex flex-col overflow-hidden h-[calc(100vh-65px)]"
    >
      <div
        ref={chatContainerRef}
        className="flex-grow pb-32 pt-12 px-4 overflow-y-auto"
      >
        <div className="max-w-3xl mx-auto space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                "flex flex-col",
                message.type === "user" ? "items-end" : "items-start"
              )}
            >
              <div
                className={cn(
                  "max-w-[80%] px-4 py-2 rounded-2xl mb-4",
                  message.type === "user"
                    ? "bg-background border border-border rounded-br-none"
                    : "bg-muted text-foreground"
                )}
              >
                <span>{message.content}</span>
              </div>

              {/* Message actions */}
              {message.type === "system" && message.completed && (
                <div className="flex justify-end w-[80%] mt-2 mb-2">
                  <button
                    className="text-muted-foreground hover:text-foreground transition-colors"
                    onClick={() => copyMessageToClipboard(message.content)}
                  >
                    <Copy className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="flex w-full bottom-0 left-0 right-0 py-4">
        <form onSubmit={handleSubmit} className="max-w-3xl mx-auto w-full">
          <div
            ref={inputContainerRef}
            className={cn(
              "relative w-full rounded-3xl border border-input p-3 cursor-text bg-background",
              isStreaming && "opacity-80"
            )}
            onClick={handleInputContainerClick}
          >
            <div className="pb-9">
              <Textarea
                ref={textareaRef}
                placeholder="Type your answer..."
                className="min-h-[24px] max-h-[160px] w-full rounded-3xl border-0 bg-transparent text-foreground placeholder:text-muted-foreground placeholder:text-base focus-visible:ring-0 focus-visible:ring-offset-0 shadow-none text-base pl-2 pr-4 pt-0 pb-0 resize-none overflow-y-auto leading-tight"
                value={inputValue}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                disabled={currentQuestionIndex >= questions.length}
              />
            </div>

            <div className="absolute bottom-3 left-3 right-3">
              <div className="flex items-center justify-between">
                <Button
                  type="submit"
                  variant="outline"
                  size="icon"
                  className={cn(
                    "ml-auto rounded-full h-8 w-8 border-0 flex-shrink-0 transition-all duration-200",
                    hasTyped ? "bg-primary" : "bg-muted"
                  )}
                  disabled={
                    !inputValue.trim() ||
                    isStreaming ||
                    currentQuestionIndex >= questions.length
                  }
                >
                  <ArrowUp
                    className={cn(
                      "h-4 w-4 transition-colors",
                      hasTyped
                        ? "text-primary-foreground"
                        : "text-muted-foreground"
                    )}
                  />
                  <span className="sr-only">Submit</span>
                </Button>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
