import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface JobDescriptionInputProps {
  onSubmit: (jobDescription: string) => void;
}

export function JobDescriptionInput({ onSubmit }: JobDescriptionInputProps) {
  const [jobDescription, setJobDescription] = useState<string>("");
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    setIsLoading(true);

    try {
      // Pass the job description to the parent component
      onSubmit(jobDescription);
    } catch (error) {
      console.error("Error submitting job description:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSkip = () => {
    // Submit with empty job description
    onSubmit("");
  };

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-65px)] p-4">
      <Card className="w-full max-w-2xl">
        <form onSubmit={handleSubmit}>
          <CardHeader>
            <CardTitle className="text-xl">Enter Job Description</CardTitle>
            <CardDescription>
              Provide the job description to generate more tailored interview
              questions. This will help create questions specific to the role
              you're applying for.
            </CardDescription>
          </CardHeader>

          <CardContent>
            <Textarea
              placeholder="Paste the job description here..."
              className="min-h-[200px] resize-none"
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
            />
          </CardContent>

          <CardFooter className="flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={handleSkip}
              disabled={isLoading}
            >
              Skip
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Processing..." : "Start Interview"}
            </Button>
          </CardFooter>
        </form>
      </Card>
    </div>
  );
}

export default JobDescriptionInput;
