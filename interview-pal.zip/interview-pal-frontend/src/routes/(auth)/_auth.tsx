import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { ThemeProvider } from "@/components/theme-provider";
// import "@fontsource/inter";
import { Toaster } from "@/components/ui/toaster";
import { ModeToggle } from "@/components/mode-toggle";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { GlobalProvider } from "@/utils/global-provider";
import { useGlobalProvider } from "@/hooks/use-global-provider";
import { useEffect } from "react";

const queryClient = new QueryClient();

export const Route = createFileRoute("/(auth)/_auth")({
  component: AuthLayout,
});

function AuthLayoutContent() {
  const { session, isResetPasswordValid } = useGlobalProvider();
  const navigate = useNavigate();

  useEffect(() => {
    if (session && !isResetPasswordValid) {
      navigate({ to: "/home", replace: true });
    }
  }, [session, isResetPasswordValid, navigate]);

  return (
    <>
      <Outlet />
      <Toaster />
      <div className="fixed bottom-4 right-4 z-50">
        <ModeToggle />
      </div>
    </>
  );
}

function AuthLayout() {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={"max-h-screen bg-background font-sans antialiased"}>
        <QueryClientProvider client={queryClient}>
          <GlobalProvider>
            <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
              <AuthLayoutContent />
            </ThemeProvider>
          </GlobalProvider>
        </QueryClientProvider>
      </body>
    </html>
  );
}
