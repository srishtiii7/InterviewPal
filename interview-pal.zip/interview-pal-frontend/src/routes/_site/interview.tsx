import ChatInterface from "@/components/chat-interface";
import InterviewResults from "@/components/interview-result";
import JobDescriptionInput from "@/components/job-description-upload";
import { useUser } from "@/hooks/use-user";
import InterviewService from "@/services/interview-service";
import { createFileRoute } from "@tanstack/react-router";
import { Loader2 } from "lucide-react";
import { useState } from "react";

export const Route = createFileRoute("/_site/interview")({
  component: RouteComponent,
});

export type QuestionType = "technical" | "behavioral" | "project";

// Interface for interview questions
export interface InterviewQuestion {
  id: number;
  question: string;
  type: QuestionType;
}

interface QuestionFeedback {
  question_id: number;
  score: number;
  feedback: string;
  improvement_suggestions: string;
}

interface OverallFeedback {
  overall_score: number;
  strengths: string;
  improvement_areas: string;
  preparation_advice: string;
}

interface Feedback {
  question_feedback: QuestionFeedback[];
  overall_feedback: OverallFeedback;
}

function RouteComponent() {
  const { user } = useUser();
  const userId = user?.id || "guest"; // Use guest ID if user not logged in

  const [jobDescription, setJobDescription] = useState<string | null>(null);
  const [questions, setQuestions] = useState<InterviewQuestion[]>([]);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [interviewComplete, setInterviewComplete] = useState<boolean>(false);
  const [feedbackGenerated, setFeedbackGenerated] = useState<boolean>(false);
  const [resultId, setResultId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const [viewState, setViewState] = useState<
    "job-input" | "interview" | "results"
  >("job-input");

  const handleJobDescriptionSubmit = async (description: string) => {
    setJobDescription(description);
    await fetchInterviewQuestions(description);
  };

  const fetchInterviewQuestions = async (description: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const fetchedQuestions = await InterviewService.generateQuestions(
        userId,
        description
      );
      setQuestions(fetchedQuestions);
      setViewState("interview"); // Move to interview view after questions are loaded
    } catch (err) {
      console.error("Error fetching questions:", err);
      setError("Failed to generate interview questions. Please try again.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleInterviewComplete = async (
    userAnswers: Record<number, string>,
    isComplete: boolean
  ) => {
    // Save the answers
    setAnswers(userAnswers);

    if (isComplete) {
      setInterviewComplete(true);

      // Generate feedback
      setIsLoading(true);
      try {
        const result = await InterviewService.generateFeedback(
          userId,
          questions,
          userAnswers,
          jobDescription || ""
        );

        setResultId(result.resultId);
        setFeedback(result.feedback);
        setFeedbackGenerated(true);
        setViewState("results"); // Explicitly set view to results after feedback is generated
      } catch (err) {
        console.error("Error generating feedback:", err);
        setError("Failed to generate feedback. Please try again.");
      } finally {
        setIsLoading(false);
      }
    }
  };

  const resetInterview = () => {
    setJobDescription(null);
    setQuestions([]);
    setAnswers({});
    setInterviewComplete(false);
    setFeedbackGenerated(false);
    setResultId(null);
    setFeedback(null);
    setError(null);
    setViewState("job-input");
  };

  // Render loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-65px)]">
        <div className="flex flex-col items-center">
          <Loader2 className="h-10 w-10 animate-spin text-primary" />
          <p className="mt-4 text-lg text-muted-foreground">
            {viewState === "job-input"
              ? "Preparing your interview..."
              : interviewComplete
              ? "Analyzing your responses and generating feedback..."
              : "Generating questions..."}
          </p>
        </div>
      </div>
    );
  }

  // Render error state
  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-65px)]">
        <div className="flex flex-col items-center max-w-lg text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={resetInterview}
            className="px-4 py-2 rounded bg-primary text-primary-foreground"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  // Render view based on current state
  switch (viewState) {
    case "job-input":
      return <JobDescriptionInput onSubmit={handleJobDescriptionSubmit} />;

    case "results":
      if (feedback) {
        return (
          <InterviewResults
            resultId={resultId || "temp-result-id"}
            questions={questions}
            answers={answers}
            feedback={feedback}
            onStartNewInterview={resetInterview}
          />
        );
      }
      // If we somehow get here without feedback, show error
      return (
        <div className="flex items-center justify-center min-h-[calc(100vh-65px)]">
          <div className="flex flex-col items-center max-w-lg text-center">
            <p className="text-red-500 mb-4">
              Something went wrong with the feedback generation.
            </p>
            <button
              onClick={resetInterview}
              className="px-4 py-2 rounded bg-primary text-primary-foreground"
            >
              Start Over
            </button>
          </div>
        </div>
      );

    case "interview":
    default:
      return (
        <ChatInterface
          userId={userId}
          questions={questions}
          onInterviewComplete={handleInterviewComplete}
        />
      );
  }
}
